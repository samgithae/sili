<?php
/**
 * Created by PhpStorm.
 * User: hudutech
 * Date: 6/18/17
 * Time: 8:22 PM
 */

define("MOBILE_PRODUCT", "Asili Africa");
define("CURRENCY_CODE", "KES");
define("AMOUNT", 4000);
define("API_KEY", "f42c7891297ab4d77e9874d563024151be7867b2bceae93e7682340d71a8f7d8");
define("API_USERNAME", "njerucyrus");
