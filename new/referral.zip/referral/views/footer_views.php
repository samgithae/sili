<?php
/**
 * Created by PhpStorm.
 * User: New LAptop
 * Date: 01/06/2017
 * Time: 00:38
 */
?>


<script src="../public/assets/js/jquery-3.2.1.min.js"></script>
<script src="../public/assets/js/bootstrap.min.js"></script>
<script src="../public/assets/js/main.js"></script>


<script src="../public/assets/js/vendor/respond.min.js"></script>
<script src="../public/assets/js/vendor/placeholdem.min.js"></script>

<script src="../public/assets/js/vendor/hoverIntent.js"></script>
<script src="../public/assets/js/vendor/superfish.js"></script>
<script src="../public/assets/js/vendor/jquery.actual.min.js"></script>
<script src="../public/assets/js/vendor/jquery.elastislide.js"></script>
<script src="../public/assets/js/vendor/jquery.flexslider-min.js"></script>
<script src="../public/assets/js/vendor/jquery.prettyPhoto.js"></script>
<script src="../public/assets/js/vendor/jquery.easing.1.3.js"></script>
<script src="../public/assets/js/vendor/jquery.ui.totop.js"></script>
<script src="../public/assets/js/vendor/jquery.isotope.min.js"></script>
<script src="../public/assets/js/vendor/jquery.easypiechart.min.js"></script>
<script src='../public/assets/js/vendor/jflickrfeed.min.js'></script>
<script src="../public/assets/js/vendor/jquery.sticky.js"></script>
<script src='../public/assets/js/vendor/owl.carousel.min.js'></script>
<script src='../public/assets/js/vendor/jquery.nicescroll.min.js'></script>
<script src='../public/assets/js/vendor/jquery.fractionslider.min.js'></script>
<script src='../public/assets/js/vendor/jquery.scrollTo-min.js'></script>
<script src='../public/assets/js/vendor/jquery.localscroll-min.js'></script>
<script src='../public/assets/js/vendor/jquery.parallax-1.1.3.js'></script>

<script src="../public/assets/js/plugins.js"></script>
<script src="../public/assets/js/main.js"></script>
